class Auvergne:
    qp=''
    sb=''
    cp=''
    def __init__(self, quantite_produit,substance,code_postal):
        self.qp=quantite_produit
        self.sb=substance
        self.cp=code_postal


def affiche_une_valeur(distrib):
    print(distrib.qp+ " "+distrib.sb+ " "+distrib.cp)
    
