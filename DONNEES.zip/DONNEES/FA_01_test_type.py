from FA_00_type import*

fichier = open("Amatou.csv" , "r") 
lines = fichier.readlines()  #lecture de fichier
colonne= lines[4].split(";")  
distrib= Auvergne(colonne[4],colonne[7],colonne[10])
affiche_une_valeur(distrib)

fichier.close()
