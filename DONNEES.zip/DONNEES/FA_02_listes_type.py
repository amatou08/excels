#fonction de la partie précedente
class Auvergne:
    qp=''
    sb=''
    cp=''
    def __init__(self, quantite_produit,substance,code_postal):
        self.qp=quantite_produit
        self.sb=substance
        self.cp=code_postal


def affiche_une_valeur(distrib):
    print(distrib.qp+ " "+distrib.sb+ " "+distrib.cp)
    


# fonction qui affiche une liste de listes de chaine de caractères(outils_fichier_csv)
#def lecture_fichier_csv( "Amatou.csv",";", "UTF-8", 3):

'''fichier = open("Amatou.csv","r", "UTF-8")
        cr = csv.reader(fichier,";")#delimiter = delimitateur)

        for i in range(nb_lignes_entete):
            cr.__next__()   # Spécificité Python permettant de passer
                            #à la ligne suivante du csv

        resultat = []
        for ligne in cr:
            resultat.append(ligne)

        fichier.close()
        return resultat
    except:
        return []'''





    
