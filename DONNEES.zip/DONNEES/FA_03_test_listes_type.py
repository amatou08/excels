from FA_02_listes_type import*

fichier = open("Amatou.csv","r")
lines = fichier.readlines()
for i in range (1,len(lines),1):
    colonne= lines[i].split(";")
    distrib=Auvergne(colonne[4],colonne[7],colonne[10])
    affiche_une_valeur(distrib)

fichier.close()





    
