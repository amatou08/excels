#from outils_fichier_csv import*
from FA_02_listes_type import*
#les fichiers sont placés dans le dossier"DONNEES"
fichier0="FA_data_0.csv"
fichier1="FA_data_1.csv"
fichier2="FA_data_5.csv"
fichier3="FA_data_20.csv"
fichier4="FA_data_100.csv"
#lecture des fichiers
#fichier0
fichier0=open("FA_data_0.csv","r")           #sur python les fichiers(modifiés) sont introuvables pourtant ils sont bien enregistrés sur l'ordi
lines=fichier0.readlines()
for i in range (0,len(lines),1):
    data0=liste_de_liste(data0[i])
    affiche_une_valeur(data0)
print("le nombre de ligne de",fichier0,"est",len(data0))

fichier.close()

#fichier1
fichier1=open("FA_data_1.csv","r")
lines=fichier1.readlines()
for i in range(0,len(lines),1):
    data1=liste_de_liste(data1[i])
    affiche_une_valeur(data1)
print("le nombre de ligne de",fichier1,"est",len(data1))

fichier.close()

#fichier2
fichier2=open("FA_data_2.csv","r")
lines=fichier2.readlines()
for i in range(0,len(lines),1):
    data2=liste_de_liste(data2[i])
    affiche_une_valeur(data2)
print("le nombre de ligne de",fichier2,"est",len(data2))

fichier.close()

#fichier3
fichier3=open("FA_data_3.csv","r")
lines=fichier3.readlines()
for i in range(0,len(lines),1):
    data3=liste_de_liste(data3[i])
    affiche_une_valeur(data3)
print("le nombre de ligne de",fichier3,"est",len(data3))

fichier.close()
#fichier4
fichier4=open("FA_data_4.csv","r")
lines=fichier4.readlines()
for i in range(0,len(lines),1):
    data4=liste_de_liste(data4[i])
    affiche_une_valeur(data4)
print("le nombre de ligne de",fichier4,"est",len(data4))

fichier.close()
